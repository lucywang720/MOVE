import wandb
import numpy as np
import torch
import collections
import pathlib
import tqdm
import dill
import math
import torch.nn as nn
import wandb.sdk.data_types.video as wv
from diffusion_policy.env.pusht.pusht_keypoints_env import PushTKeypointsEnv
from diffusion_policy.gym_util.async_vector_env import AsyncVectorEnv
# from diffusion_policy.gym_util.sync_vector_env import SyncVectorEnv
from diffusion_policy.gym_util.multistep_wrapper import MultiStepWrapper
from diffusion_policy.gym_util.video_recording_wrapper import VideoRecordingWrapper, VideoRecorder

from diffusion_policy.policy.base_lowdim_policy import BaseLowdimPolicy
from diffusion_policy.common.pytorch_util import dict_apply
from diffusion_policy.env_runner.base_lowdim_runner import BaseLowdimRunner

# def calc_norm(action): # 56,1,2
#     action = torch.tensor(action)
#     # print(action.shape, action, action.sum(dim=1))
#     # print(torch.norm(action.sum(dim=1).reshape(1, -1), dim=-1))
#     return torch.norm(action.sum(dim=1).reshape(1, -1), dim=-1)

def calc_norm(action): # 56,1,2
    action = torch.tensor(action)
    # print(action.shape, action, action.sum(dim=1))
    # print(torch.norm(action.sum(dim=1).reshape(1, -1), dim=-1))
    return torch.norm(action.reshape(1, -1), dim=-1)

class PushTKeypointsRunner(BaseLowdimRunner):
    def __init__(self,
            output_dir,
            keypoint_visible_rate=1.0,
            n_train=10,
            n_train_vis=3,
            train_start_seed=0,
            n_test=22,
            n_test_vis=6,
            legacy_test=False,
            test_start_seed=10000,
            max_steps=200,
            n_obs_steps=8,
            n_action_steps=8,
            n_latency_steps=0,
            fps=10,
            crf=22,
            agent_keypoints=False,
            past_action=False,
            tqdm_interval_sec=5.0,
            n_envs=None,
            policies=None
        ):
        super().__init__(output_dir)

        if n_envs is None:
            n_envs = n_train + n_test

        # handle latency step
        # to mimic latency, we request n_latency_steps additional steps 
        # of past observations, and the discard the last n_latency_steps
        env_n_obs_steps = n_obs_steps + n_latency_steps
        env_n_action_steps = n_action_steps

        # assert n_obs_steps <= n_action_steps
        kp_kwargs = PushTKeypointsEnv.genenerate_keypoint_manager_params()

        def env_fn():
            return MultiStepWrapper(
                VideoRecordingWrapper(
                    PushTKeypointsEnv(
                        legacy=legacy_test,
                        keypoint_visible_rate=keypoint_visible_rate,
                        agent_keypoints=agent_keypoints,
                        **kp_kwargs
                    ),
                    video_recoder=VideoRecorder.create_h264(
                        fps=fps,
                        codec='h264',
                        input_pix_fmt='rgb24',
                        crf=crf,
                        thread_type='FRAME',
                        thread_count=1
                    ),
                    file_path=None,
                ),
                n_obs_steps=env_n_obs_steps,
                n_action_steps=env_n_action_steps,
                max_episode_steps=max_steps
            )

        env_fns = [env_fn] * n_envs
        env_seeds = list()
        env_prefixs = list()
        env_init_fn_dills = list()
        # train
        for i in range(n_train):
            seed = train_start_seed + i
            enable_render = i < n_train_vis

            def init_fn(env, seed=seed, enable_render=enable_render):
                # setup rendering
                # video_wrapper
                assert isinstance(env.env, VideoRecordingWrapper)
                env.env.video_recoder.stop()
                env.env.file_path = None
                if enable_render:
                    filename = pathlib.Path(output_dir).joinpath(
                        'media', wv.util.generate_id() + ".mp4")
                    filename.parent.mkdir(parents=False, exist_ok=True)
                    filename = str(filename)
                    env.env.file_path = filename

                # set seed
                assert isinstance(env, MultiStepWrapper)
                env.seed(seed)
            
            env_seeds.append(seed)
            env_prefixs.append('train/')
            env_init_fn_dills.append(dill.dumps(init_fn))

        # test
        for i in range(n_test):
            seed = test_start_seed + i
            enable_render = i < n_test_vis

            def init_fn(env, seed=seed, enable_render=enable_render):
                # setup rendering
                # video_wrapper
                assert isinstance(env.env, VideoRecordingWrapper)
                env.env.video_recoder.stop()
                env.env.file_path = None
                if enable_render:
                    filename = pathlib.Path(output_dir).joinpath(
                        'media', wv.util.generate_id() + ".mp4")
                    filename.parent.mkdir(parents=False, exist_ok=True)
                    filename = str(filename)
                    env.env.file_path = filename

                # set seed
                assert isinstance(env, MultiStepWrapper)
                env.seed(seed)

            env_seeds.append(seed)
            env_prefixs.append('test/')
            env_init_fn_dills.append(dill.dumps(init_fn))

        env = AsyncVectorEnv(env_fns)

        # test env
        # env.reset(seed=env_seeds)
        # x = env.step(env.action_space.sample())
        # imgs = env.call('render')
        # import pdb; pdb.set_trace()

        self.env = env
        self.env_fns = env_fns
        self.env_seeds = env_seeds
        self.env_prefixs = env_prefixs
        self.env_init_fn_dills = env_init_fn_dills
        self.fps = fps
        self.crf = crf
        self.agent_keypoints = agent_keypoints
        self.n_obs_steps = n_obs_steps
        self.n_action_steps = n_action_steps
        self.n_latency_steps = n_latency_steps
        self.past_action = past_action
        self.max_steps = max_steps
        self.tqdm_interval_sec = tqdm_interval_sec
        self.policy = nn.Sequential(*policies)
        self.exit_record = [0, 0, 0, 0, 0, 0]

        self.first_step = 0
        # print(self.policy)
    
    def run(self):
    # def run(self, policy: BaseLowdimPolicy):
        device = self.policy[0].device
        dtype = self.policy[0].dtype

        env = self.env

        # plan for rollout
        n_envs = len(self.env_fns)
        # print("n_envs: ", n_envs)
        n_inits = len(self.env_init_fn_dills)
        n_chunks = math.ceil(n_inits / n_envs)

        # allocate data
        all_video_paths = [None] * n_inits
        all_rewards = [None] * n_inits

        for chunk_idx in range(n_chunks):
            start = chunk_idx * n_envs
            end = min(n_inits, start + n_envs)
            this_global_slice = slice(start, end)
            this_n_active_envs = end - start
            this_local_slice = slice(0,this_n_active_envs)
            
            this_init_fns = self.env_init_fn_dills[this_global_slice]
            n_diff = n_envs - len(this_init_fns)
            if n_diff > 0:
                this_init_fns.extend([self.env_init_fn_dills[0]]*n_diff)
            assert len(this_init_fns) == n_envs

            # init envs
            env.call_each('run_dill_function', 
                args_list=[(x,) for x in this_init_fns])

            # start rollout
            obs = env.reset()
            past_action = None
            for i in range(len(self.policy)):
                self.policy[i].reset()

            pbar = tqdm.tqdm(total=self.max_steps, desc=f"Eval PushtKeypointsRunner {chunk_idx+1}/{n_chunks}", 
                leave=False, mininterval=self.tqdm_interval_sec)
            done = False
            while not done:
                Do = obs.shape[-1] // 2
                # create obs dict
                np_obs_dict = {
                    # handle n_latency_steps by discarding the last n_latency_steps
                    'obs': obs[...,:self.n_obs_steps,:Do].astype(np.float32),
                    'obs_mask': obs[...,:self.n_obs_steps,Do:] > 0.5
                }

                # print(np_obs_dict['obs'], np_obs_dict['obs'].shape, np_obs_dict['obs_mask'], np_obs_dict['obs_mask'].shape)
                if self.past_action and (past_action is not None):
                    # TODO: not tested
                    print("into past action")
                    np_obs_dict['past_action'] = past_action[
                        :,-(self.n_obs_steps-1):].astype(np.float32)
                
                # device transfer
                obs_dict = dict_apply(np_obs_dict, 
                    lambda x: torch.from_numpy(x).to(
                        device=device))

                # print('--------------')
                # print(obs_dict['obs'].shape)

                action = []
                action_norm = []
                # threshold = [504.524902343755, 483.68695068359375, 486.06109619140625, 444.8839111328125, 461.8745422363281]
                # threshold = [461.8745422363281, 444.8839111328125, 486.06109619140625, 483.68695068359375, 504.524902343755, 0]
                threshold = [167.75323486328125, 114.26316833496094, 98.58969116210938, 202.05177307128906, 77.9091796875, 0]
                # threshold = [162.9603729248047, 108.90056610107422, 87.93372344970703, 10000, 77.49966430664062, 0]
                threshold = [77.89273834228516, 218.7422332763672, 205.49853515625, 0, 254.45713806152344, 1000]


                # run policy
                with torch.no_grad():
                    for i in range(len(self.policy)):
                        j = len(self.policy) - i - 1
                        action_dict = self.policy[j].predict_action(obs_dict)
                        # print(action_dict.keys())
                        np_action_dict = dict_apply(action_dict,
                            lambda x: x.detach().to('cpu').numpy())
                        action.append(np_action_dict['action'][:,self.n_latency_steps:])
                        # print(action.shape)
                        # action = np.ones(action.shape) * 100
                        action_norm.append(calc_norm(action[i][:,-1] - action[i][:,0]))
                        # print("-", action_norm[-1], np_action_dict['action'][:,self.n_latency_steps:].shape)
                        if action_norm[-1] <= threshold[i]:
                            action = action[-1]
                            with open('/diffusion_policy/list.txt', 'r', encoding='utf-8') as file:
                                content = file.read().strip()
                                content = content[1:-1]
                                my_list = [int(x.strip()) for x in content.split(',')]
                                print(my_list)
                                my_list[j] += 1
                            with open('/diffusion_policy/list.txt', 'w', encoding='utf-8') as file:
                                file.write(str(my_list))
                            self.exit_record[j] += 1
                            print(self.exit_record)
                            break
                        # print(action_dict['action'])

                # print(action_norm)

                # 4 8 16 32 64 128
                # threshold = [504.524902343755, 483.68695068359375, 486.06109619140625, 444.8839111328125, 461.8745422363281]

                # give_action = False
                # for i in range(len(threshold)):
                #     if action_norm[6-i-1] >= threshold[i]:
                #         action = action[6-i-1]
                #         give_action = True
                #         break

                # if not give_action:
                #     action = action[0]
                


                # # device_transfer
                # np_action_dict = dict_apply(action_dict,
                #     lambda x: x.detach().to('cpu').numpy())

                # # handle latency_steps, we discard the first n_latency_steps actions
                # # to simulate latency
                # action = np_action_dict['action'][:,self.n_latency_steps:]
                # print(action.shape)
                # # action = np.ones(action.shape) * 100
                # tmp = action[:,1:] - action[:,:-1]
                # print(tmp.shape)


                # step env

                # print("action shape: ", action.shape)
                obs, reward, done, info = env.step(action)
                done = np.all(done)
                past_action = action

                # update pbar
                pbar.update(action.shape[1])
            pbar.close()

            # collect data for this round
            all_video_paths[this_global_slice] = env.render()[this_local_slice]
            all_rewards[this_global_slice] = env.call('get_attr', 'reward')[this_local_slice]
        # import pdb; pdb.set_trace()

        # log
        max_rewards = collections.defaultdict(list)
        log_data = dict()
        # results reported in the paper are generated using the commented out line below
        # which will only report and average metrics from first n_envs initial condition and seeds
        # fortunately this won't invalidate our conclusion since
        # 1. This bug only affects the variance of metrics, not their mean
        # 2. All baseline methods are evaluated using the same code
        # to completely reproduce reported numbers, uncomment this line:
        # for i in range(len(self.env_fns)):
        # and comment out this line
        print(n_inits, len(self.env_fns))
        for i in range(n_inits):
            seed = self.env_seeds[i]
            prefix = self.env_prefixs[i]
            max_reward = np.max(all_rewards[i])
            max_rewards[prefix].append(max_reward)
            log_data[prefix+f'sim_max_reward_{seed}'] = max_reward
            print(all_rewards[i], max_reward)

            # visualize sim
            video_path = all_video_paths[i]
            if video_path is not None:
                sim_video = wandb.Video(video_path)
                log_data[prefix+f'sim_video_{seed}'] = sim_video

        # log aggregate metrics
        for prefix, value in max_rewards.items():
            name = prefix+'mean_score'
            value = np.mean(value)
            log_data[name] = value

        return log_data
